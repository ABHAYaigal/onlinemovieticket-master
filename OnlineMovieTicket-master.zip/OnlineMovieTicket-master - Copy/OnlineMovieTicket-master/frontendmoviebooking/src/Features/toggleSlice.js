import { createSlice } from "@reduxjs/toolkit";


export const  toggleSlice=createSlice({
    name:"logintoggle",
    initialState:{value:{isLoggedIn:""}},
    
},
)

