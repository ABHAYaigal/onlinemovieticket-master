import React from 'react';
import AddTheatre from '../Components/AddTheatre';

const TheatrePage = () => {
  return (
    <div>
      <AddTheatre/>
    </div>
  );
}

export default TheatrePage;
